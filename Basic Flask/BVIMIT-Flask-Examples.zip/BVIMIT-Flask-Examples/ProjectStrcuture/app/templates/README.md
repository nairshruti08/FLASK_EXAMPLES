This directory contains application templates.
